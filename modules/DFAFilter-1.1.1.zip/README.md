# DFAFilter 敏感词过滤模块

## 功能简介
基于DFA(Deterministic Finite Automaton)算法实现的高效敏感词过滤系统，支持：
- 实时敏感词检测
- 自动替换敏感词
- 动态更新词库
- 中英文混合过滤

## 快速开始

1. 确保已在`env.py`中配置敏感词库：
```python
sdk.env.set("DFAFilter.words", '''\
敏感词1
敏感词2
敏感词3
''')
```

2. 在代码中使用：
```python
# 初始化
dfa = sdk.DFAFilter

# 检测敏感词
has_sensitive = dfa.check("测试文本")

# 过滤文本
filtered_text = dfa.filter("包含敏感词的文本")

# 添加新词
dfa.add("新敏感词")

# 更新词库
dfa.update("新词1\n新词2\n新词3")
```

## API文档

### `check(text: str) -> bool`
- 功能：检查文本是否包含敏感词
- 参数：待检测文本
- 返回：True(包含敏感词)/False(不包含)

### `filter(text: str, replace_char: str = '*') -> str`
- 功能：过滤文本中的敏感词(替换为*)
- 参数：原始文本
- 返回：过滤后的文本

### `add(word: str) -> bool`
- 功能：添加单个敏感词
- 参数：要添加的敏感词
- 返回：True(添加成功)/False(词库已存在)

### `remove(word: str) -> bool`
- 功能：删除单个敏感词
- 参数：要删除的敏感词
- 返回：True(删除成功)/False(词不存在)

### `list() -> list`
- 功能：列出所有敏感词
- 返回：敏感词列表

### `update(words_str: str) -> bool`
- 功能：完全覆盖更新敏感词库(会清空原有词库)
- 参数：多行敏感词字符串(每行一个词)
- 返回：True(更新成功)/False(更新失败)

### `clear() -> bool`
- 功能：清空敏感词库
- 返回：True(清空成功)/False(清空失败)

## 示例代码
```python
# 初始化DFA过滤器
dfa = sdk.DFAFilter

# 1. 基础使用示例
text = "这是一段包含敏感词1和敏感词2的测试文本"
if dfa.check(text):  # 检查文本是否包含敏感词
    filtered = dfa.filter(text)  # 过滤敏感词(默认替换为*)
    print(f"过滤结果: {filtered}")

# 2. 动态添加新敏感词
dfa.add("新敏感词")  # 添加单个敏感词
print(f"添加后检测结果: {dfa.check('包含新敏感词的文本')}")

# 3. 批量更新词库(注意:会清空原有词库)
new_words = "词A\n词B\n词C"
dfa.update(new_words)  # 完全更新词库
print(f"当前词库: {dfa.list()}")  # 列出所有敏感词

# 4. 删除敏感词
dfa.remove("敏感词1")  # 删除指定敏感词
print(f"删除后检测结果: {dfa.check('包含敏感词1的文本')}")
```