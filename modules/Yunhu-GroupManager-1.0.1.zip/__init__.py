moduleInfo = {
    "meta": {
        "name": "Yunhu-GroupManager",
        "version": "1.0.1",
        "description": "群聊管理模块，支持敏感词过滤、消息撤回和黑名单管理",
        "author": "wsu2059q",
        "homepage": "https://github.com/wsu2059q/ErisPulse-Yunhu-GroupManager",
        "license": "MIT"
    },
    "dependencies": {
        "requires": ["DFAFilter", "YunhuAdapter"],
        "optional": [],
        "pip": []
    }
}

from .Core import Main
# build_hash="919ff051ba68de76d6108ad3872782f4cf5cda546eac13b7c194790de77e36ec"
