import asyncio
from typing import Dict, List, AsyncGenerator
from ErisPulse import sdk

class Main:
    def __init__(self, sdk):
        self.sdk = sdk
        self.logger = sdk.logger
        self.env = sdk.env
        self.openai = sdk.OpenAI
        self.is_setup = False
        self.active_generations = {}  # 跟踪正在进行的生成任务 {chat_id: task}
        
        self.history_key = "novel_generator.chat_history"
        if not self.env.get(self.history_key):
            self.env.set(self.history_key, {})
            
        self.style_key = "novel_generator.style_settings"
        if not self.env.get(self.style_key):
            self.env.set(self.style_key, {})
        
        self._setup_event_handlers()
        self.logger.info("群聊小说生成器模块已加载")
    
    def _setup_event_handlers(self):
        if self.is_setup:
            return
            
        @sdk.adapter.Yunhu.on("message")
        async def handle_message(data):
            try:
                await self.record_message(data)
            except Exception as e:
                self.logger.error(f"处理消息时出错: {e}")

        @sdk.adapter.Yunhu.on("command")
        async def handle_command(data):
            try:
                event = data["event"]
                command = event["message"]["commandName"]
                chat_type = event["chat"]["chatType"]
                chat_id = event["chat"]["chatId"]
                sender_id = event["sender"]["senderId"]
                if chat_type != "group":
                    sdk.adapter.Yunhu.Send.To("user", sender_id).Text("该指令仅可在群聊中使用")
                    return
                if command == "生成小说":
                    text = event["message"]["content"]["text"]
                    extra_prompt = text.replace("/生成小说", "").strip()
                    if len(extra_prompt) > 150:
                        await sdk.adapter.Yunhu.Send.To(chat_type, chat_id).Text("额外提示词不宜超过150字")
                        return
                    await sdk.adapter.Yunhu.Send.To(chat_type, chat_id).Text("米库正在思考小说内容，请稍候...")
                    try:
                        await sdk.adapter.Yunhu.Send.To(chat_type, chat_id).Stream(
                            "markdown",
                            self.generate_novel(extra_prompt, chat_id)
                        )
                    except Exception as e:
                        self.logger.error(f"生成小说时出错: {e}")

                elif command == "清除历史":
                    history = self.env.get(self.history_key, {})
                    if chat_id in history:
                        history[chat_id] = []
                        self.env.set(self.history_key, history)
                    await sdk.adapter.Yunhu.Send.To(chat_type, chat_id).Text("当前聊天历史记录已清除")
                    
                elif command == "查看历史":
                    history = self.env.get(self.history_key, {})
                    if not history.get(chat_id):
                        await sdk.adapter.Yunhu.Send.To(chat_type, chat_id).Text("当前聊天暂无历史记录")
                        return
                    
                    response = "当前聊天的最近消息记录：\n"
                    for msg in history[chat_id][-50:]:
                        response += f"{msg['name']}: {msg['message']}\n"
                    await sdk.adapter.Yunhu.Send.To(chat_type, chat_id).Text(response)
                elif command == "设置风格":
                    style = event["message"]["content"]["text"].replace("/设置风格", "").strip()
                    if len(style) > 100:
                        await sdk.adapter.Yunhu.Send.To(chat_type, chat_id).Text("风格长度不能超过100个字符")
                        return
                    if style:
                        settings = self.env.get(self.style_key, {})
                        settings[chat_id] = style
                        self.env.set(self.style_key, settings)
                        await sdk.adapter.Yunhu.Send.To(chat_type, chat_id).Text(f"已设置本群小说风格为: {style}")
                elif command == "查看风格":
                    settings = self.env.get(self.style_key, {})
                    current_style = settings.get(chat_id, "轻小说会话体（带实况解说）")
                    await sdk.adapter.Yunhu.Send.To(chat_type, chat_id).Text(f"当前群小说风格: {current_style}")
                    
                elif command == "取消生成":
                    if chat_id in self.active_generations:
                        task = self.active_generations[chat_id]
                        task.cancel()
                        del self.active_generations[chat_id]
                        await sdk.adapter.Yunhu.Send.To(chat_type, chat_id).Text("已取消当前生成任务")
                    else:
                        await sdk.adapter.Yunhu.Send.To(chat_type, chat_id).Text("当前没有正在进行的生成任务")
            
            except Exception as e:
                self.logger.error(f"处理指令时出错: {e}")

        self.is_setup = True

    async def record_message(self, event_data: Dict) -> None:
        try:
            sender = event_data["event"]["sender"]
            message = event_data["event"]["message"]["content"]["text"]
            timestamp = event_data["event"]["message"]["sendTime"]
            chat_id = event_data["event"]["chat"]["chatId"]
            chat_type = event_data["event"]["chat"]["chatType"]
            sender_id = sender["senderId"]

            if chat_type != "group":
                sdk.adapter.Yunhu.Send.To("user", sender_id).Text("机器人仅可在群聊中使用")
                return
            if message.strip() == "" or message == "生成小说" or message == "清除历史":
                return
            
            user_name = sender["senderNickname"]
            
            history = self.env.get(self.history_key, {})
            if chat_id not in history:
                history[chat_id] = []
                
            history[chat_id].append({
                "timestamp": timestamp,
                "name": user_name,
                "message": message
            })
            
            self.env.set(self.history_key, history)
            self.logger.debug(f"已记录来自 {user_name} 的消息到聊天 {chat_id}")
            
        except Exception as e:
            self.logger.error(f"记录消息时出错: {e}")

    def _build_prompt(self, chat_id: str, extra_prompt: str = "") -> str:
        settings = self.env.get(self.style_key, {})
        style = settings.get(chat_id, "轻小说会话体（带实况解说）")
        history = self.env.get(self.history_key, {}).get(chat_id, [])
        
        prompt = f"""# 小说创作任务说明

## 角色设定
你是一位专业小说家，负责将群聊记录改编成生动的小说。

## 格式要求
- 使用MarkDown语法输出
- 不要使用 ```markdown ``` 代码块包裹内容

## 创作规范
### 内容要求
1. 必须基于对话内容创作完整故事，禁止直接复述对话
2. 充分展现人物的心理活动和情感变化
3. 保持原用户昵称，可设计符合性格的外貌特征
4. 字数控制在500-750字之间

### 风格要求
1. 主体风格: {style}
2. 语言要求生动形象，适当使用比喻手法
3. 结构要求：
   - 每3-5段形成一个完整场景
   - 章节之间要有自然过渡

## 素材处理说明
以下群聊记录将作为故事素材，请充分发挥创造力：
    """
        
        if extra_prompt:
            prompt += f"\n## 额外创作提示\n{extra_prompt}\n"
            
        prompt += "\n## 原始聊天素材\n"
        
        for msg in history[-50:]:
            if len(msg["message"]) > 100:
                continue
            prompt += f"- {msg['name']}：{msg['message']}\n"
                
        prompt += """
        
## 输出要求
请直接开始创作，输出完整的小说内容：
- 不要提及这是改编自聊天记录
- 保持Markdown格式
- 确保故事完整性和连贯性
"""
        return prompt


    async def generate_novel(self, extra_prompt: str = "", chat_id: str = "") -> AsyncGenerator[bytes, None]:
        try:
            if chat_id in self.active_generations:
                yield "当前聊天已有正在进行的生成任务，请等待完成或使用/取消生成命令".encode('utf-8')
                return
                
            history = self.env.get(self.history_key, {}).get(chat_id, [])
            if not history:
                yield "当前聊天没有可用的历史记录，无法生成小说".encode('utf-8')
                return
                
            task = asyncio.current_task()
            self.active_generations[chat_id] = task
                
            prompt = self._build_prompt(chat_id, extra_prompt)
            messages = [{"role": "user", "content": prompt}]
            
            buffer = bytearray()
            buffer_size = 1024
            last_send_time = asyncio.get_event_loop().time()
            send_interval = 0.1
            
            try:
                async for chunk in self.openai.chat_stream(messages):
                    if isinstance(chunk, str):
                        chunk = chunk.encode('utf-8')
                    buffer.extend(chunk)
                    current_time = asyncio.get_event_loop().time()
                    if len(buffer) >= buffer_size or (current_time - last_send_time) >= send_interval:
                        if buffer:
                            yield bytes(buffer)
                            buffer.clear()
                            last_send_time = current_time
                if buffer:
                    yield bytes(buffer)
            except asyncio.CancelledError:
                self.logger.info(f"聊天 {chat_id} 的小说生成任务已取消")
                raise
        except Exception as e:
            self.logger.error(f"生成小说时出错: {e}")
            yield "生成小说时出错，请稍后再试".encode('utf-8')
            raise
        finally:
            if chat_id in self.active_generations:
                del self.active_generations[chat_id]