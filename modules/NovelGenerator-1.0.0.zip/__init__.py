moduleInfo = {
    "meta": {
        "name": "NovelGenerator",
        "version": "1.0.0",
        "description": "群聊小说生成器模块",
        "author": "ErisPulse",
        "license": "MIT"
    },
    "dependencies": {
        "requires": ["OpenAI"],
        "optional": [],
        "pip": []
    }
}

from .Core import Main