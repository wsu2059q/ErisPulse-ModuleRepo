moduleInfo = {
    "meta": {
        "name": "Yunhu-GroupManager",
        "version": "1.0.0",
        "description": "群聊管理模块，支持敏感词过滤、消息撤回和黑名单管理",
        "author": "Craft",
        "license": "MIT"
    },
    "dependencies": {
        "requires": ["DFAFilter", "YunhuAdapter"],
        "optional": [],
        "pip": []
    }
}

from .Core import Main