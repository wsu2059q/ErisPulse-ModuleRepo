from ErisPulse import sdk
import asyncio

class Main:
    def __init__(self, sdk):
        self.sdk = sdk
        self.logger = sdk.logger
        self.env = sdk.env
        self.util = sdk.util
        self.raiserr = sdk.raiserr
        
        # 初始化敏感词过滤器
        self.dfa = sdk.DFAFilter
        
        # 动态存储key
        self.dynamic_keys = {
            'global_admins': "GroupManager.dynamic_global_admins",
            'global_blacklist': "GroupManager.dynamic_global_blacklist",
            'group_sensitive_words': "GroupManager.dynamic_group_sensitive_words",
            'group_blacklists': "GroupManager.dynamic_group_blacklists"
        }
        
        # 加载全局管理员列表 (初始配置+动态存储)
        init_admins = self.env.get("GroupManager.global_admins", [])
        dynamic_admins = self.env.get(self.dynamic_keys['global_admins'], [])
        self.global_admin_ids = list(set(init_admins + dynamic_admins))
        self.logger.info(f"加载了 {len(self.global_admin_ids)} 个全局管理员 (初始{len(init_admins)}个, 动态{len(dynamic_admins)}个)")
        
        # 加载全局黑名单 (初始配置+动态存储)
        init_blacklist = self.env.get("GroupManager.global_blacklist", [])
        dynamic_blacklist = self.env.get(self.dynamic_keys['global_blacklist'], [])
        self.global_blacklist = list(set(init_blacklist + dynamic_blacklist))
        if self.global_blacklist is None:
            self.global_blacklist = []
            self.env.set("GroupManager.global_blacklist", [])
            self.env.set(self.dynamic_keys['global_blacklist'], [])
        self.logger.info(f"加载了 {len(self.global_blacklist)} 个全局黑名单用户 (初始{len(init_blacklist)}个, 动态{len(dynamic_blacklist)}个)")
        
        # 加载群级别的敏感词和黑名单 (初始配置+动态存储)
        init_group_words = self.env.get("GroupManager.group_sensitive_words", {})
        dynamic_group_words = self.env.get(self.dynamic_keys['group_sensitive_words'], {})
        self.group_sensitive_words = self._merge_dicts(init_group_words, dynamic_group_words)
        
        init_group_blacklists = self.env.get("GroupManager.group_blacklists", {})
        dynamic_group_blacklists = self.env.get(self.dynamic_keys['group_blacklists'], {})
        self.group_blacklists = self._merge_dicts(init_group_blacklists, dynamic_group_blacklists)
        
        # 记录DFA过滤器中的敏感词数量（全局敏感词）
        self.logger.info(f"DFA过滤器加载了 {len(self.dfa.list())} 个全局敏感词")
        
        # 注册消息处理器
        sdk.adapter.Yunhu.on("message")(self.handle_message)
        sdk.adapter.Yunhu.on("command")(self.handle_command)
        
        self.logger.info("群管模块已加载")

    async def handle_message(self, data):
        try:
            event = data.get("event", {})
            sender = event.get("sender", {})
            message = event.get("message", {})
            
            # 获取发送者信息
            sender_id = sender.get("senderId", "")
            sender_type = sender.get("senderType", "")
            sender_name = sender.get("senderNickname", "")
            chat_type = event.get("chat", {}).get("chatType", "")
            chat_id = event.get("chat", {}).get("chatId", "")
            msg_id = message.get("msgId", "")
            text = message.get("content", {}).get("text", "")
            self.logger.debug(f"消息发送者: {sender_id}, {sender_type}, {sender_name}")
            self.logger.debug(f"消息类型: {self.global_admin_ids}")
            self.logger.debug(f"是否为全局管理员: {sender_id in self.global_admin_ids}")
            if sender_id in self.global_admin_ids and text.startswith("全局"):
                self.logger.debug(f"处理全局命令: {text}")
                command_parts = text.split(" ", 1)
                command = command_parts[0]
                param = command_parts[1] if len(command_parts) > 1 else ""
                self.logger.debug(f"全局命令: {command}, 参数: {param}")
                
                if command == "全局添加敏感词":
                    if param:
                        success = self.dfa.add(param)
                        if success:
                            await self.send_message(chat_type, chat_id, f"已添加全局敏感词: {param}")
                        else:
                            await self.send_message(chat_type, chat_id, f"全局敏感词 '{param}' 已存在")
                        return
                
                elif command == "全局移除敏感词":
                    if param:
                        success = self.dfa.remove(param)
                        if success:
                            await self.send_message(chat_type, chat_id, f"已移除全局敏感词: {param}")
                        else:
                            await self.send_message(chat_type, chat_id, f"全局敏感词 '{param}' 不存在")
                        return
                
                elif command == "全局添加黑名单":
                    if param and param not in self.global_blacklist:
                        self.global_blacklist.append(param)
                        # 更新动态存储
                        current_dynamic = self.env.get(self.dynamic_keys['global_blacklist'], [])
                        if param not in current_dynamic:
                            current_dynamic.append(param)
                            self.env.set(self.dynamic_keys['global_blacklist'], current_dynamic)
                        await self.send_message(chat_type, chat_id, f"已添加全局黑名单用户: {param}")
                    else:
                        await self.send_message(chat_type, chat_id, f"用户ID不能为空或已在全局黑名单中")
                    return
                
                elif command == "全局移除黑名单":
                    if param in self.global_blacklist:
                        self.global_blacklist.remove(param)
                        # 更新动态存储
                        current_dynamic = self.env.get(self.dynamic_keys['global_blacklist'], [])
                        if param in current_dynamic:
                            current_dynamic.remove(param)
                            self.env.set(self.dynamic_keys['global_blacklist'], current_dynamic)
                        await self.send_message(chat_type, chat_id, f"已移除全局黑名单用户: {param}")
                    else:
                        await self.send_message(chat_type, chat_id, f"用户 '{param}' 不在全局黑名单中")
                    return
                
                elif command == "全局敏感词列表":
                    words = self.dfa.list()
                    words_text = "\n".join(words) if words else "暂无全局敏感词"
                    await self.send_message(chat_type, chat_id, f"全局敏感词列表:\n{words_text}")
                    return
                
                elif command == "全局黑名单列表":
                    users = "\n".join(self.global_blacklist) if self.global_blacklist else "暂无全局黑名单用户"
                    await self.send_message(chat_type, chat_id, f"全局黑名单用户:\n{users}")
                    return
                
                elif command == "全局帮助":
                    help_text = """全局管理员命令(仅机器人可用):
全局添加敏感词 [词语] - 添加全局敏感词
全局移除敏感词 [词语] - 移除全局敏感词
全局添加黑名单 [用户ID] - 添加用户到全局黑名单
全局移除黑名单 [用户ID] - 从全局黑名单移除用户
全局敏感词列表 - 查看所有全局敏感词
全局黑名单列表 - 查看所有全局黑名单用户
全局帮助 - 显示全局管理员帮助信息"""
                    await self.send_message(chat_type, chat_id, help_text)
                    return
            
            # 检查是否在全局黑名单中
            if sender_id in self.global_blacklist:
                await self.warn_user(chat_type, chat_id, sender_name, "你在全局黑名单中，无法发言")
                await self.recall_message(chat_type, chat_id, msg_id)
                return
            
            # 如果是群消息，检查是否在群黑名单中
            if chat_type == "group" and chat_id in self.group_blacklists:
                group_blacklist = self.group_blacklists.get(chat_id, [])
                if sender_id in group_blacklist:
                    await self.warn_user(chat_type, chat_id, sender_name, "你在该群黑名单中，无法发言")
                    await self.recall_message(chat_type, chat_id, msg_id)
                    return
            
            # 检查是否包含全局敏感词
            if self.dfa.check(text):
                warning_msg = "你的消息包含全局敏感词"
                await self.warn_user(chat_type, chat_id, sender_name, warning_msg)
                await self.recall_message(chat_type, chat_id, msg_id)
                return
            
            # 如果是群消息，检查是否包含群敏感词
            if chat_type == "group" and chat_id in self.group_sensitive_words:
                group_words = self.group_sensitive_words.get(chat_id, [])
                for word in group_words:
                    if word in text:
                        warning_msg = "你的消息包含该群敏感词"
                        await self.warn_user(chat_type, chat_id, sender_name, warning_msg)
                        await self.recall_message(chat_type, chat_id, msg_id)
                        return
                    
        except Exception as e:
            self.logger.error(f"处理消息时出错: {e}")

    async def handle_command(self, data):
        try:
            self.logger.debug(f"收到命令: {data}")
            event = data.get("event", {})
            sender = event.get("sender", {})
            message = event.get("message", {})
            
            sender_id = sender.get("senderId", "")
            sender_user_level = sender.get("senderUserLevel", "")
            chat_type = event.get("chat", {}).get("chatType", "")
            chat_id = event.get("chat", {}).get("chatId", "")
            command = message.get("instructionName", "") or message.get("commandName", "")
            command = command.lower()
            text = message.get("content", {}).get("text", "")
            
            # 提取命令参数
            # 如果text中有空格，则按空格分隔提取参数；否则整个text就是参数
            param = text.split(" ", 1)[1] if " " in text else text
            self.logger.debug(f"命令: {command}, 文本: {text}, 参数: {param}")
            
            # 检查是否为全局管理员
            is_global_admin = sender_id in self.global_admin_ids
            
            # 检查是否为群管理员
            is_group_admin = sender.get('senderUserLevel', '') in ['owner', 'admin']
            
            # 如果是全局命令，忽略它（全局命令现在通过消息事件处理）
            if command.startswith("全局"):
                return
            
            # 群命令处理
            # 如果不是群聊，拒绝执行群命令
            if chat_type != "group":
                await self.send_message(chat_type, chat_id, "群管理命令只能在群聊中使用")
                return
            
            # 如果不是群管理员或全局管理员，拒绝执行
            if not (is_group_admin or is_global_admin):
                await self.send_message(chat_type, chat_id, "你不是群管理员或全局管理员，无法执行此操作")
                return
            
            if command == "添加敏感词":
                if param:
                    # 获取当前群的敏感词列表
                    group_words = self.group_sensitive_words.get(chat_id, [])
                    if param not in group_words:
                        group_words.append(param)
                        self.group_sensitive_words[chat_id] = group_words
                        # 更新动态存储
                        dynamic_words = self.env.get(self.dynamic_keys['group_sensitive_words'], {})
                        if chat_id not in dynamic_words:
                            dynamic_words[chat_id] = []
                        if param not in dynamic_words[chat_id]:
                            dynamic_words[chat_id].append(param)
                            self.env.set(self.dynamic_keys['group_sensitive_words'], dynamic_words)
                        await self.send_message(chat_type, chat_id, f"已添加群敏感词: {param}")
                    else:
                        await self.send_message(chat_type, chat_id, f"群敏感词 '{param}' 已存在")
            
            elif command == "移除敏感词":
                if param:
                    group_words = self.group_sensitive_words.get(chat_id, [])
                    if param in group_words:
                        group_words.remove(param)
                        self.group_sensitive_words[chat_id] = group_words
                        # 更新动态存储
                        dynamic_words = self.env.get(self.dynamic_keys['group_sensitive_words'], {})
                        if chat_id in dynamic_words and param in dynamic_words[chat_id]:
                            dynamic_words[chat_id].remove(param)
                            self.env.set(self.dynamic_keys['group_sensitive_words'], dynamic_words)
                        await self.send_message(chat_type, chat_id, f"已移除群敏感词: {param}")
                    else:
                        await self.send_message(chat_type, chat_id, f"群敏感词 '{param}' 不存在")
        
            elif command == "添加黑名单":
                if param:
                    # 获取当前群的黑名单列表
                    group_blacklist = self.group_blacklists.get(chat_id, [])
                    if param not in group_blacklist:
                        group_blacklist.append(param)
                        self.group_blacklists[chat_id] = group_blacklist
                        # 更新动态存储
                        dynamic_blacklists = self.env.get(self.dynamic_keys['group_blacklists'], {})
                        if chat_id not in dynamic_blacklists:
                            dynamic_blacklists[chat_id] = []
                        if param not in dynamic_blacklists[chat_id]:
                            dynamic_blacklists[chat_id].append(param)
                            self.env.set(self.dynamic_keys['group_blacklists'], dynamic_blacklists)
                        await self.send_message(chat_type, chat_id, f"已添加群黑名单用户: {param}")
                    else:
                        await self.send_message(chat_type, chat_id, f"用户已在群黑名单中")
            
            elif command == "移除黑名单":
                if param:
                    group_blacklist = self.group_blacklists.get(chat_id, [])
                    if param in group_blacklist:
                        group_blacklist.remove(param)
                        self.group_blacklists[chat_id] = group_blacklist
                        # 更新动态存储
                        dynamic_blacklists = self.env.get(self.dynamic_keys['group_blacklists'], {})
                        if chat_id in dynamic_blacklists and param in dynamic_blacklists[chat_id]:
                            dynamic_blacklists[chat_id].remove(param)
                            self.env.set(self.dynamic_keys['group_blacklists'], dynamic_blacklists)
                        await self.send_message(chat_type, chat_id, f"已移除群黑名单用户: {param}")
                    else:
                        await self.send_message(chat_type, chat_id, f"用户不在群黑名单中")
            
            elif command == "敏感词列表":
                # 获取群敏感词列表
                group_words = self.group_sensitive_words.get(chat_id, [])
                group_words_text = "\n".join(group_words) if group_words else "暂无群敏感词"
                
                # 获取全局敏感词列表
                global_words = self.dfa.list()
                global_words_text = "\n".join(global_words) if global_words else "暂无全局敏感词"
                
                await self.send_message(chat_type, chat_id, f"群敏感词列表:\n{group_words_text}\n\n全局敏感词列表:\n{global_words_text}")
            
            elif command == "黑名单列表":
                # 获取群黑名单列表
                group_blacklist = self.group_blacklists.get(chat_id, [])
                group_users = "\n".join(group_blacklist) if group_blacklist else "暂无群黑名单用户"
                
                # 获取全局黑名单列表
                global_users = "\n".join(self.global_blacklist) if self.global_blacklist else "暂无全局黑名单用户"
                
                await self.send_message(chat_type, chat_id, f"群黑名单用户:\n{group_users}\n\n全局黑名单用户:\n{global_users}")
        
            # 帮助命令
            elif command == "帮助":
                help_text = """群管模块指令:

群管理员命令:
/添加敏感词 [词语] - 添加群敏感词
/移除敏感词 [词语] - 移除群敏感词
/添加黑名单 [用户ID] - 添加用户到群黑名单
/移除黑名单 [用户ID] - 从群黑名单移除用户
/敏感词列表 - 查看敏感词列表
/黑名单列表 - 查看黑名单用户
/帮助 - 显示帮助信息"""
                
                await self.send_message(chat_type, chat_id, help_text)
                
        except Exception as e:
            self.logger.error(f"处理指令时出错: {e}")
        
    async def send_message(self, chat_type, chat_id, text):
        await sdk.adapter.Yunhu.Send.To(chat_type, chat_id).Text(text)

    async def warn_user(self, chat_type, chat_id, user_neckname, message):
        await self.send_message(chat_type, chat_id, f"@{user_neckname} {message}")

    def _merge_dicts(self, dict1, dict2):
        """合并两个字典，对于相同key的值，合并为列表并去重"""
        result = {}
        # 处理dict1的所有key
        for key in dict1:
            if key in dict2:
                # 合并两个字典中的列表
                result[key] = list(set(dict1[key] + dict2[key]))
            else:
                result[key] = dict1[key]
        # 处理dict2中独有的key
        for key in dict2:
            if key not in dict1:
                result[key] = dict2[key]
        return result

    async def recall_message(self, chat_type, chat_id, msg_id):
        try:
            await sdk.adapter.Yunhu.Send.To(chat_type, chat_id).Recall(msg_id)
        except Exception as e:
            self.logger.error(f"撤回消息失败: {e}")