moduleInfo = {
    "meta": {
        "name": "Yunhu-NovelGenerator",
        "version": "1.0.0",
        "description": "群聊小说生成器模块",
        "author": "ErisPulse",
        "license": "MIT"
    },
    "dependencies": {
        "requires": ["OpenAI", "DFAFilter"],
        "optional": [],
        "pip": []
    }
}

from .Core import Main
# build_hash="86485d26da57269459f98aaeb9066e2393fbff80444438e5c53f91f788a5ab1b"
