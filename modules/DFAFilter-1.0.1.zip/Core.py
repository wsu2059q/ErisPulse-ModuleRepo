from ErisPulse import sdk

class Main:
    def __init__(self, sdk):
        self.sdk = sdk
        self.logger = sdk.logger
        self.word_list_key = "DFAFilter.words"
        
        self.ban_words_set = set()
        self.ban_words_list = list()
        self.ban_words_dict = dict()
        
        self._load_words_from_env()
        
    def _load_words_from_env(self):
        words_str = self.sdk.env.get(self.word_list_key, "")
        if words_str:
            self._load_words(words_str)
            self.logger.debug("从环境变量加载敏感词库")
            self.logger.info(f"DFAFilter 模块已加载, 共有敏感词: {len(self.ban_words_list)}个")
        else:
            self.logger.debug(f"""未找到配置项 {self.word_list_key}, 请在 env.py 中配置

# 敏感词保持对于大部分敏感词库的兼容,保持一行一个词即可
sdk.env.set("{self.word_list_key}", '''\
敏感词1
敏感词2
敏感词3
''')      

""")
            
    def filter(self, text, replace_char='*'):
        pos_list = []
        ss = self._draw_words(text, pos_list)
        illegal_pos = self._find_illegal(ss)
        while illegal_pos != -1:
            ss = self._filter_words(ss, illegal_pos, replace_char)
            illegal_pos = self._find_illegal(ss)
        i = 0
        while i < len(ss):
            if ss[i] == replace_char:
                start = pos_list[i]
                while i < len(ss) and ss[i] == replace_char:
                    i += 1
                i -= 1
                end = pos_list[i]
                num = end - start + 1
                text = text[:start] + replace_char * num + text[end + 1:]
            i += 1
        return text
        
    def check(self, text):
        pos = self._find_illegal(text)
        return pos != -1
        
    def add(self, word):
        if not isinstance(word, str):
            self.logger.error(f"添加敏感词失败: {word} 不是字符串")
            return False
        try:
            word = str(word)
            if word not in self.ban_words_set:
                self.ban_words_set.add(word)
                self.ban_words_list.append(word)
                self._add_to_dict(word)
                self.logger.debug(f"添加敏感词: {word}")
            else:
                self.logger.debug(f"添加敏感词失败: {word} 已存在")
                return False
            return True
        except Exception as e:
            self.logger.error(f"添加敏感词失败: {e}")
            return False
        
    def update(self, words_str):
        try:
            self.ban_words_set.clear()
            self.ban_words_list.clear()
            self.ban_words_dict.clear()
            self._load_words(words_str)
            self.logger.info(f"敏感词库已更新，当前共有 {len(self.ban_words_list)} 个敏感词")
            return True
        except Exception as e:
            self.logger.error(f"敏感词库更新失败: {e}")
            return False
    def clear(self):
        try:
            self.ban_words_set.clear()
            self.ban_words_list.clear()
            self.ban_words_dict.clear()
            self.logger.info(f"敏感词库已清空")
            return True
        except Exception as e:
            self.logger.error(f"敏感词库清空失败: {e}")
            return False
    def remove(self, word):
        word = str(word)
        if word in self.ban_words_set:
            self.ban_words_set.remove(word)
            self.ban_words_list.remove(word)
            self._build_dict()  # 重建字典
            self.logger.debug(f"删除敏感词: {word}")
            return True
        return False
        
    def list(self):
        return self.ban_words_list.copy()
        
    def _load_words(self, words_str):
        lines = words_str.strip().split('\n')
        for word in lines:
            word = word.strip()
            if word and word not in self.ban_words_set:
                self.ban_words_set.add(word)
                self.ban_words_list.append(word)
        self._build_dict()
    
    def _add_to_dict(self, word):
        now_dict = self.ban_words_dict
        for i, char in enumerate(word):
            if char not in now_dict:
                new_dict = {}
                new_dict['is_end'] = False
                now_dict[char] = new_dict
                now_dict = new_dict
            else:
                now_dict = now_dict[char]
            if i == len(word) - 1:
                now_dict['is_end'] = True
    
    def _build_dict(self):
        self.ban_words_dict = {}
        for word in self.ban_words_list:
            self._add_to_dict(word)
    
    def _find_illegal(self, text):
        now_dict = self.ban_words_dict
        i = 0
        start_word = -1
        is_start = True
        while i < len(text):
            if text[i] not in now_dict:
                if is_start:
                    i += 1
                    continue
                i = start_word + 1
                start_word = -1
                is_start = True
                now_dict = self.ban_words_dict
            else:
                if is_start:
                    start_word = i
                    is_start = False
                now_dict = now_dict[text[i]]
                if now_dict['is_end']:
                    return start_word
                i += 1
        return -1
    
    def _filter_words(self, text, pos, replace_char='*'):
        now_dict = self.ban_words_dict
        end_str = pos
        for i in range(pos, len(text)):
            if text[i] not in now_dict:
                break
            now_dict = now_dict[text[i]]
            if now_dict['is_end']:
                end_str = i
                break
        num = end_str - pos + 1
        return text[:pos] + replace_char * num + text[end_str + 1:]
    
    @staticmethod
    def _draw_words(text, pos_list):
        result = ""
        for i, char in enumerate(text):
            if ('\u4e00' <= char <= '\u9fa5' or  # 中文
                '\u3400' <= char <= '\u4db5' or  # 扩展中文
                '\u0030' <= char <= '\u0039' or  # 数字
                '\u0061' <= char <= '\u007a' or  # 小写字母
                '\u0041' <= char <= '\u005a'):   # 大写字母
                result += char
                pos_list.append(i)
        return result