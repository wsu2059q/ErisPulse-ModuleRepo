moduleInfo = {
    "meta": {
        "name": "YunhuMessageBatch",
        "version": "1.0.1",
        "description": "云湖 | 批量消息发送模块，支持向多个对象同时推送",
        "author": "r1a, WSu2059",
        "license": "MIT",
        "homepage": "https://github.com/wsu2059q/ErisPulse-YunhuAdapter"
    },
    "dependencies": {
        "requires": ["YunhuMessageBase"],
        "optional": [],
        "pip": []
    }
}
from .Core import Main
