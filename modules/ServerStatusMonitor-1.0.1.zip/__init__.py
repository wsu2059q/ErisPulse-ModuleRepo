moduleInfo = {
    "meta": {
        "name": "ServerStatusMonitor",
        "version": "1.0.1",
        "description": "全平台系统信息查询模块",
        "author": "wsu2059q",
        "homepage": "https://github.com/wsu2059q/ErisPulse-ServerStatusMonitor",
        "license": "MIT"
    },
    "dependencies": {
        "requires": ["SystemStatus"],
        "optional": [],
        "pip": []
    }
}

from .Core import Main
# build_hash="fb5d3f3b6932d9455184a124affb02d5210c99e2298abb43988610938845a02f"
