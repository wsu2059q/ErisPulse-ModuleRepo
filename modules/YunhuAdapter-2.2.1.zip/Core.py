import asyncio
import aiohttp
from aiohttp import web
import json
import logging
from typing import Dict, List, Optional, Any
from ErisPulse import sdk

class Main:
    def __init__(self, sdk):
        self.sdk = sdk
        self.logger = sdk.logger

    def register_adapters(self):
        self.logger.debug("注册云湖适配器")
        return {
            "Yunhu": YunhuAdapter
        }

class YunhuAdapter(sdk.BaseAdapter):
    class Send(sdk.SendDSL):
        def Text(self, text: str, buttons: List = None, parent_id: str = ""):
            return asyncio.create_task(
                self._adapter.call_api(
                    endpoint="/bot/send",
                    recvId=self._target_id,
                    recvType=self._target_type,
                    contentType="text",
                    content={"text": text, "buttons": buttons},
                    parentId=parent_id
                )
            )

        def Html(self, html: str, buttons: List = None, parent_id: str = ""):
            return asyncio.create_task(
                self._adapter.call_api(
                    endpoint="/bot/send",
                    recvId=self._target_id,
                    recvType=self._target_type,
                    contentType="html",
                    content={"text": html, "buttons": buttons},
                    parentId=parent_id
                )
            )

        def Markdown(self, markdown: str, buttons: List = None, parent_id: str = ""):
            return asyncio.create_task(
                self._adapter.call_api(
                    endpoint="/bot/send",
                    recvId=self._target_id,
                    recvType=self._target_type,
                    contentType="markdown",
                    content={"text": markdown, "buttons": buttons},
                )
            )

        def Image(self, file: bytes, buttons: List = None, parent_id: str = ""):
            return asyncio.create_task(
                self._upload_file_and_call_api(
                    "/image/upload",
                    field_name="image",
                    file=file,
                    endpoint="/bot/send",
                    content_type="image",
                    buttons=buttons,
                    parent_id=parent_id
                )
            )

        def Video(self, file: bytes, buttons: List = None, parent_id: str = ""):
            return asyncio.create_task(
                self._upload_file_and_call_api(
                    "/video/upload",
                    field_name="video",
                    file=file,
                    endpoint="/bot/send",
                    content_type="video",
                    buttons=buttons,
                    parent_id=parent_id
                )
            )

        def File(self, file: bytes, buttons: List = None, parent_id: str = ""):
            return asyncio.create_task(
                self._upload_file_and_call_api(
                    "/file/upload",
                    field_name="file",
                    file=file,
                    endpoint="/bot/send",
                    content_type="file",
                    buttons=buttons,
                    parent_id=parent_id
                )
            )

        def Batch(self, target_ids: List[str], message: Any, content_type: str = "text", **kwargs):
            content = {"text": message} if isinstance(message, str) else {}
            return asyncio.create_task(
                self._adapter.call_api(
                    endpoint="/bot/batch_send",
                    recvIds=target_ids,
                    recvType=self._target_type,
                    contentType=content_type,
                    content=content,
                    **kwargs
                )
            )

        def Edit(self, msg_id: str, text: str, buttons: List = None):
            return asyncio.create_task(
                self._adapter.call_api(
                    endpoint="/bot/edit",
                    msgId=msg_id,
                    recvId=self._target_id,
                    recvType=self._target_type,
                    contentType="text",
                    content={"text": text, "buttons": buttons}
                )
            )

        def Recall(self, msg_id: str):
            return asyncio.create_task(
                self._adapter.call_api(
                    endpoint="/bot/recall",
                    msgId=msg_id,
                    chatId=self._target_id,
                    chatType=self._target_type
                )
            )

        def Board(self, scope: str, content: str, **kwargs):
            if scope == "local":
                return asyncio.create_task(
                    self._adapter.call_api(
                        endpoint="/bot/board",
                        chatId=kwargs["chat_id"],
                        chatType=kwargs["chat_type"],
                        contentType=kwargs.get("content_type", "text"),
                        content={"text": content},
                        memberId=kwargs.get("member_id", ""),
                        expireTime=kwargs.get("expire_time", 0)
                    )
                )
            else:
                return asyncio.create_task(
                    self._adapter.call_api(
                        endpoint="/bot/board-all",
                        contentType=kwargs.get("content_type", "text"),
                        content={"text": content},
                        expireTime=kwargs.get("expire_time", 0)
                    )
                )

        def DismissBoard(self, scope: str, **kwargs):
            if scope == "local":
                return asyncio.create_task(
                    self._adapter.call_api(
                        endpoint="/bot/board-dismiss",
                        chatId=kwargs["chat_id"],
                        chatType=kwargs["chat_type"],
                        memberId=kwargs.get("member_id", "")
                    )
                )
            else:
                return asyncio.create_task(
                    self._adapter.call_api(endpoint="/bot/board-all-dismiss")
                )

        def Stream(self, content_type: str, content_generator, **kwargs):
            return asyncio.create_task(
                self._adapter.send_stream(
                    conversation_type=self._target_type,
                    target_id=self._target_id,
                    content_type=content_type,
                    content_generator=content_generator,
                    **kwargs
                )
            )

        async def CheckExist(self, message_id: str):
            endpoint = "/bot/messages"
            params = {
                "chat-id": self._target_id,
                "chat-type": self._target_type,
                "message-id": message_id,
                "before": 0,
                "after": 0
            }
            url = f"{self._adapter.base_url}{endpoint}?token={self._adapter.yhToken}"
            async with self._adapter.session.get(url, params=params) as response:
                data = await response.json()
                if data.get("code") != 1:
                    self.logger.warning(f"云湖API返回异常: {data}")
                    return False
                msg_list = data.get("data", {}).get("list", [])
                return any(msg["msgId"] == message_id for msg in msg_list)

        async def _upload_file_and_call_api(self, upload_endpoint, field_name, file, endpoint, content_type, **kwargs):
            url = f"{self._adapter.base_url}{upload_endpoint}?token={self._adapter.yhToken}"
            data = aiohttp.FormData()
            data.add_field(
                field_name,
                file,
                filename=f"file.{field_name}",
                content_type="application/octet-stream"
            )

            async with self._adapter.session.post(url, data=data) as response:
                upload_res = await response.json()

            key_map = {
                "image": "imageKey",
                "video": "videoKey",
                "file": "fileKey"
            }
            key_name = key_map.get(field_name)

            payload = {
                "recvId": self._target_id,
                "recvType": self._target_type,
                "contentType": content_type,
                "content": {key_name: upload_res["data"][key_name]},
                "parentId": kwargs.get("parent_id", "")
            }

            if "buttons" in kwargs:
                payload["content"]["buttons"] = kwargs["buttons"]

            return await self._adapter.call_api(endpoint, **payload)

    def __init__(self, sdk):
        super().__init__()
        self.sdk = sdk
        self.logger = logging.getLogger(__name__)
        self.config = self._load_config()
        self.yhToken = self.config.get("token", "")
        self.session: Optional[aiohttp.ClientSession] = None
        self.server: Optional[web.AppRunner] = None
        self.base_url = "https://chat-go.jwzhd.com/open-apis/v1"
        self.poll_task = None
        self._setup_event_mapping()

    def _load_config(self) -> Dict:
        config = self.sdk.env.get("YunhuAdapter", {})
        if not config:
            example_config = """
                示例配置:

                sdk.env.set("YunhuAdapter", {
                    # 必填：云湖 Bot Token
                    "token": "YOUR_YUNHU_BOT_TOKEN",

                    # 启动模式: server 或 polling
                    "mode": "server",

                    # Webhook 模式下的服务配置（如使用 server）
                    "server": {
                        "host": "127.0.0.1",            # 推荐监听本地，防止外网直连
                        "port": 8443,                   # 监听端口
                        "path": "/yunhu/webhook"         # Webhook 路径
                    },

                    # 轮询模式下的 SSE 配置（如使用 polling）
                    "sse": {
                        "sse_url": "https://your-cf-worker.example/sse",  # CF Worker 提供的 SSE 地址
                        "max_retries": 10,                              # 最大重试次数
                        "retry_interval": 5,                            # 重试间隔秒数
                        "timeout": 30                                   # 单次请求超时时间
                    }
                })
            """
            self.logger.warning(example_config.strip())
        return config

    def _setup_event_mapping(self):
        self.event_map = {
            "message.receive.normal": "message",
            "message.receive.instruction": "command",
            "bot.followed": "follow",
            "bot.unfollowed": "unfollow",
            "group.join": "group_join",
            "group.leave": "group_leave",
            "button.report.inline": "button_click",
            "bot.shortcut.menu": "shortcut_menu"
        }

    async def start(self):
        mode = self.config.get("mode", "server")  # 默认 server 模式
        if mode == "server":
            await self.start_server()
        elif mode == "polling":
            await self._start_polling()
        else:
            self.logger.error(f"未知的启动模式: {mode}")

    async def shutdown(self):
        if self.poll_task:
            self.poll_task.cancel()
            try:
                await self.poll_task
            except asyncio.CancelledError:
                pass
            self.poll_task = None

        if self.server:
            await self.stop_server()

        if self.session:
            await self.session.close()
            self.session = None

        self.logger.info("云湖适配器已关闭")

    async def start_server(self):
        if not self.config.get("server"):
            self.logger.warning("Webhook服务器未配置，将不会启动")
            return

        server_config = self.config["server"]
        app = web.Application()
        app.router.add_post(
            server_config.get("path", "/"),
            self._handle_webhook
        )

        self.server = web.AppRunner(app)
        await self.server.setup()

        site = web.TCPSite(
            self.server,
            server_config.get("host", "127.0.0.1"),
            server_config.get("port", 8080)
        )
        await site.start()
        self.logger.info(f"Webhook服务器已启动: {site.name}")

    async def stop_server(self):
        if self.server:
            await self.server.cleanup()
            self.server = None
            self.logger.info("Webhook服务器已停止")

    async def _start_polling(self):
        """启动 polling 模式，从CF Worker的SSE接口获取事件"""
        sse_config = self.config.get("sse", {})
        sse_url = sse_config.get("sse_url")
        max_retries = sse_config.get("max_retries", 10)
        retry_interval = sse_config.get("retry_interval", 5)
        timeout = sse_config.get("timeout", 30)

        if not sse_url:
            self.logger.error("polling模式需要配置 sse.sse_url")
            return

        if not self.session:
            self.session = aiohttp.ClientSession()

        self.logger.info(f"正在启动 polling 模式，连接至 SSE 地址: {sse_url}")
        self.poll_task = asyncio.create_task(
            self._poll_events(sse_url, max_retries, retry_interval, timeout)
        )

    async def _poll_events(self, sse_url: str, max_retries: int, retry_interval: int, timeout: int):
        retry_count = 0
        while True:
            try:
                async with self.session.get(sse_url, timeout=timeout) as resp:
                    if resp.status != 200:
                        self.logger.error(f"SSE 连接失败，状态码: {resp.status}")
                        retry_count += 1
                        if retry_count > max_retries:
                            self.logger.critical("超过最大重试次数，退出轮询。")
                            break
                        await asyncio.sleep(retry_interval)
                        continue

                    self.logger.info("成功连接到 SSE 接口")
                    retry_count = 0  # 成功后重置重试计数器

                    async for line in resp.content:
                        line = line.strip()
                        if line.startswith(b"data: "):
                            try:
                                event_data = json.loads(line[6:])  # 去除前缀 "data: "
                                event_type = event_data.get("data", {}).get("type", "unknown")
                                mapped_type = self.event_map.get(event_type, "unknown")

                                self.logger.debug(f"处理 polling 事件: {mapped_type} (ID: {event_data.get('id')})")
                                await self.emit(mapped_type, event_data.get("data"))
                            except Exception as e:
                                self.logger.error(f"解析 SSE 数据失败: {e}")
            except (aiohttp.ClientError, asyncio.TimeoutError) as e:
                self.logger.error(f"SSE 连接中断: {e}")
                retry_count += 1
                if retry_count > max_retries:
                    self.logger.critical("超过最大重试次数，退出轮询。")
                    break
                self.logger.info(f"将在 {retry_interval} 秒后尝试重新连接...")
                await asyncio.sleep(retry_interval)
            except Exception as e:
                self.logger.error(f"轮询异常: {e}")
                retry_count += 1
                if retry_count > max_retries:
                    self.logger.critical("超过最大重试次数，退出轮询。")
                    break
                await asyncio.sleep(retry_interval)

    async def _handle_webhook(self, request: web.Request) -> web.Response:
        try:
            data = await request.json()
            event_type = data["header"]["eventType"]
            mapped_type = self.event_map.get(event_type, "unknown")

            self.logger.debug(f"处理Webhook事件:{event_type} -> {mapped_type}")
            await self.emit(mapped_type, data)
            return web.Response(text="OK", status=200)
        except Exception as e:
            self.logger.error(f"Webhook处理错误: {str(e)}")
            return web.Response(text=f"ERROR: {str(e)}", status=500)

    async def call_api(self, endpoint: str, **params):
        self.logger.debug(f"调用API:{endpoint}")
        return await self._net_request("POST", endpoint, params)

    async def _net_request(self, method: str, endpoint: str, data: Dict = None) -> Dict:
        url = f"{self.base_url}{endpoint}?token={self.yhToken}"
        if not self.session:
            self.session = aiohttp.ClientSession()

        async with self.session.request(
            method,
            url,
            json=data,
            headers={"Content-Type": "application/json"}
        ) as response:
            return await response.json()

    async def send_stream(self, conversation_type: str, target_id: str, content_type: str, content_generator, **kwargs) -> Dict:
        endpoint = "/bot/send-stream"
        params = {
            "recvId": target_id,
            "recvType": conversation_type,
            "contentType": content_type
        }
        if "parent_id" in kwargs:
            params["parentId"] = kwargs["parent_id"]
        url = f"{self.base_url}{endpoint}?token={self.yhToken}"
        query_params = "&".join([f"{k}={v}" for k, v in params.items()])
        full_url = f"{url}&{query_params}"
        self.logger.debug(f"准备发送流式消息到 {target_id}，会话类型: {conversation_type}, 内容类型: {content_type}")
        if not self.session:
            self.session = aiohttp.ClientSession()
        headers = {"Content-Type": "text/plain"}
        async with self.session.post(full_url, headers=headers, data=content_generator) as response:
            return await response.json()
