moduleInfo = {
    "meta": {
        "name": "AIChatMessageStore",
        "version": "1.0.2",
        "description": "AI聊天模块 - 消息对话存储模块，该模块用于存储AI聊天模块的对话记录",
        "author": "WSu2059",
        "license": "MIT",
        "homepage": "https://github.com/wsu2059q/ErisPulse-AIChat"
    },
    "dependencies": {
        "requires": [],
        "optional": [],
        "pip": []
    }
}
from .Core import Main
