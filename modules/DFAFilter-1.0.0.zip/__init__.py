moduleInfo = {
    "meta": {
        "name": "DFAFilter",
        "version": "1.0.0",
        "description": "基于DFA算法的敏感词过滤模块",
        "author": "wsu2059q",
        "license": "MIT"
    },
    "dependencies": {
        "requires": [],
        "optional": [],
        "pip": []
    }
}

from .Core import Main