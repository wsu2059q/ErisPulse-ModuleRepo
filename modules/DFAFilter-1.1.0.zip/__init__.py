moduleInfo = {
    "meta": {
        "name": "DFAFilter",
        "version": "1.1.0",
        "description": "基于DFA算法的敏感词过滤模块",
        "author": "wsu2059q",
        "license": "MIT"
    },
    "dependencies": {
        "requires": [],
        "optional": [],
        "pip": []
    }
}

from .Core import Main
# build_hash="390e40d9aa10f142837c844fb82bd8b86f67febefef14b172689a0505f253e50"

# build_hash="a576324fcebc3ab14ef39191a94542459a58ef6c586dd3499e2a2ca02d30ac67"
